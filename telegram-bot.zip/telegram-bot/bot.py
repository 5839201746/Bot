import asyncio
import html
import os
import re
import secrets
import sqlite3
import string
import time

import yaml
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandObject
from aiogram.types import (
    BotCommand,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
)
from aiohttp import web

with open(os.getenv("CONFIG", "config.yml"), encoding="utf-8") as f:
    cfg = yaml.safe_load(f) or {}

BOT_TOKEN = os.getenv("BOT_TOKEN") or cfg["bot_token"]
API_SECRET = os.getenv("API_SECRET") or cfg["api_secret"]
HOST = str(cfg.get("host", "0.0.0.0"))
PORT = int(cfg.get("port", 8080))
CODE_TTL = int(cfg.get("code_ttl_seconds", 600))
CONFIRM_DAYS = float(cfg.get("confirm_days", 3))
CONFIRM_TIMEOUT = int(cfg.get("confirm_timeout_seconds", 120))
CODE_RE = re.compile(r"^[A-Z0-9]{6}$")

db = sqlite3.connect("raidbot.db", check_same_thread=False)
db.executescript(
    """
CREATE TABLE IF NOT EXISTS links (
    player_id      TEXT PRIMARY KEY,
    chat_id        INTEGER NOT NULL,
    name           TEXT,
    last_confirmed INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS codes (
    code      TEXT PRIMARY KEY,
    player_id TEXT NOT NULL,
    name      TEXT,
    created   INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS confirms (
    id         TEXT PRIMARY KEY,
    player_id  TEXT NOT NULL,
    chat_id    INTEGER NOT NULL,
    message_id INTEGER,
    status     TEXT NOT NULL,
    created    INTEGER NOT NULL
);
"""
)
# миграция со старой версии базы
_cols = [r[1] for r in db.execute("PRAGMA table_info(links)")]
if "last_confirmed" not in _cols:
    db.execute("ALTER TABLE links ADD COLUMN last_confirmed INTEGER NOT NULL DEFAULT 0")
db.commit()

bot = Bot(BOT_TOKEN)
dp = Dispatcher()

BTN_STATUS = "📋 Мои аккаунты"
BTN_UNLINK = "❌ Отвязать всё"
BTN_HELP = "ℹ️ Как привязать"

MENU = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text=BTN_STATUS), KeyboardButton(text=BTN_HELP)],
        [KeyboardButton(text=BTN_UNLINK)],
    ],
    resize_keyboard=True,
)

HELP_TEXT = (
    "Как привязать аккаунт:\n"
    "1. На сервере напиши в чат <code>/tg link</code>\n"
    "2. Нажми на ссылку из чата или отправь мне полученный код.\n\n"
    "Код действует 10 минут.\n\n"
    "После привязки при входе на сервер раз в несколько дней я буду присылать запрос "
    "с кнопками «Принять» и «Отклонить». Если отклонить — игрока кикнет с сервера."
)


def ago(ts: int) -> str:
    if not ts:
        return "вход ещё не подтверждался"
    days = int((time.time() - ts) // 86400)
    return "вход подтверждён сегодня" if days == 0 else f"вход подтверждён {days} дн. назад"


# ---------- Привязка ----------
async def bind(m: Message, code: str):
    code = code.strip().upper()
    row = db.execute(
        "SELECT player_id, name, created FROM codes WHERE code=?", (code,)
    ).fetchone()
    if not row or time.time() - row[2] > CODE_TTL:
        await m.answer(
            "❌ Код не подошёл или устарел.\nПолучи новый командой <code>/tg link</code> на сервере.",
            parse_mode="HTML",
            reply_markup=MENU,
        )
        return
    player_id, name = row[0], row[1]
    # игрок только что доказал, что он в игре — считаем вход подтверждённым
    db.execute(
        "INSERT OR REPLACE INTO links (player_id, chat_id, name, last_confirmed) VALUES (?,?,?,?)",
        (player_id, m.chat.id, name, int(time.time())),
    )
    db.execute("DELETE FROM codes WHERE code=?", (code,))
    db.commit()
    await m.answer(
        f"✅ Аккаунт <b>{html.escape(name or player_id)}</b> привязан!\n"
        f"Раз в {CONFIRM_DAYS:g} дн. при входе на сервер я буду просить подтвердить вход.",
        parse_mode="HTML",
        reply_markup=MENU,
    )


# ---------- Команды Telegram ----------
@dp.message(Command("start"))
async def start(m: Message, command: CommandObject):
    if command.args:  # ссылка t.me/bot?start=КОД
        await bind(m, command.args)
        return
    await m.answer(
        "👋 Я подтверждаю вход на сервер.\n\n" + HELP_TEXT,
        parse_mode="HTML",
        reply_markup=MENU,
    )


@dp.message(Command("help"))
@dp.message(F.text == BTN_HELP)
async def help_cmd(m: Message):
    await m.answer(HELP_TEXT, parse_mode="HTML", reply_markup=MENU)


@dp.message(Command("link"))
async def link(m: Message, command: CommandObject):
    if command.args:
        await bind(m, command.args)
    else:
        await help_cmd(m)


@dp.message(Command("status"))
@dp.message(F.text == BTN_STATUS)
async def status(m: Message):
    rows = db.execute(
        "SELECT player_id, name, last_confirmed FROM links WHERE chat_id=?", (m.chat.id,)
    ).fetchall()
    if not rows:
        await m.answer(
            "Нет привязанных аккаунтов.\n\n" + HELP_TEXT,
            parse_mode="HTML",
            reply_markup=MENU,
        )
        return
    await m.answer(
        "\n".join(f"{name or pid} — {ago(last)}" for pid, name, last in rows),
        reply_markup=MENU,
    )


@dp.message(Command("unlink"))
@dp.message(F.text == BTN_UNLINK)
async def unlink(m: Message):
    db.execute("DELETE FROM links WHERE chat_id=?", (m.chat.id,))
    db.commit()
    await m.answer("Аккаунты отвязаны.", reply_markup=MENU)


# ---------- Кнопки «Принять» / «Отклонить» ----------
@dp.callback_query(F.data.startswith(("ok:", "no:")))
async def on_decision(cb: CallbackQuery):
    action, req_id = cb.data.split(":", 1)
    row = db.execute(
        "SELECT player_id, chat_id, status, created FROM confirms WHERE id=?", (req_id,)
    ).fetchone()
    if not row or not cb.message or row[1] != cb.message.chat.id:
        await cb.answer("Запрос не найден", show_alert=True)
        return
    player_id, _, st, created = row
    if st != "pending" or time.time() - created > CONFIRM_TIMEOUT:
        db.execute("UPDATE confirms SET status='expired' WHERE id=? AND status='pending'", (req_id,))
        db.commit()
        await cb.answer("Запрос уже неактуален", show_alert=True)
        try:
            await cb.message.edit_text("⌛ Запрос устарел.")
        except Exception:
            pass
        return
    if action == "ok":
        db.execute("UPDATE confirms SET status='approved' WHERE id=?", (req_id,))
        db.execute(
            "UPDATE links SET last_confirmed=? WHERE player_id=?", (int(time.time()), player_id)
        )
        text = "✅ Вход подтверждён."
    else:
        db.execute("UPDATE confirms SET status='denied' WHERE id=?", (req_id,))
        text = "❌ Вход отклонён. Игрок будет кикнут с сервера."
    db.commit()
    try:
        await cb.message.edit_text(text)
    except Exception:
        pass
    await cb.answer()


@dp.message(F.text)
async def maybe_code(m: Message):
    text = (m.text or "").strip().upper()
    if CODE_RE.match(text):
        await bind(m, text)
    else:
        await m.answer(
            "Не понял 🤔 Отправь код из игры или выбери действие в меню.",
            reply_markup=MENU,
        )


# ---------- HTTP API для плагина ----------
def authorized(req: web.Request) -> bool:
    return secrets.compare_digest(req.headers.get("X-Secret", ""), API_SECRET)


async def api_tg_link(req: web.Request):
    """POST /tg/link {"player_id": "...", "name": "Ник"} -> {"ok": true, "code": "A1B2C3"}"""
    if not authorized(req):
        return web.json_response({"ok": False}, status=403)
    data = await req.json()
    player_id = str(data.get("player_id", "")).strip()
    if not player_id:
        return web.json_response({"ok": False, "error": "no_player_id"}, status=400)
    alphabet = string.ascii_uppercase + string.digits
    code = "".join(secrets.choice(alphabet) for _ in range(6))
    db.execute("DELETE FROM codes WHERE player_id=?", (player_id,))
    db.execute(
        "INSERT INTO codes VALUES (?,?,?,?)",
        (code, player_id, data.get("name"), int(time.time())),
    )
    db.commit()
    return web.json_response({"ok": True, "code": code, "ttl": CODE_TTL})


async def api_confirm_request(req: web.Request):
    """POST /confirm/request {"player_id","name","ip"}
    -> {"ok":true,"required":false}  подтверждение не нужно
    -> {"ok":true,"required":true,"id":"..."}  отправлен запрос в Telegram
    """
    if not authorized(req):
        return web.json_response({"ok": False}, status=403)
    data = await req.json()
    pid = str(data.get("player_id", "")).strip()
    row = db.execute(
        "SELECT chat_id, last_confirmed, name FROM links WHERE player_id=?", (pid,)
    ).fetchone()
    if not row:
        return web.json_response({"ok": True, "required": False, "linked": False})
    chat_id, last, saved_name = row
    if time.time() - last < CONFIRM_DAYS * 86400:
        return web.json_response({"ok": True, "required": False, "linked": True})

    nick = str(data.get("name") or saved_name or pid)
    ip = str(data.get("ip") or "неизвестно")
    req_id = secrets.token_hex(8)
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Принять", callback_data=f"ok:{req_id}"),
                InlineKeyboardButton(text="❌ Отклонить", callback_data=f"no:{req_id}"),
            ]
        ]
    )
    text = (
        "🔐 <b>Вход на сервер</b>\n"
        f"Игрок: <b>{html.escape(nick)}</b>\n"
        f"IP: <code>{html.escape(ip)}</code>\n\n"
        f"Это вы? Ответь в течение {CONFIRM_TIMEOUT} сек.\n"
        "Если отклонить — игрока кикнет с сервера."
    )
    # старые неотвеченные запросы этого игрока больше не действуют
    db.execute(
        "UPDATE confirms SET status='expired' WHERE player_id=? AND status='pending'", (pid,)
    )
    try:
        msg = await bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=kb)
    except Exception:
        db.commit()
        return web.json_response({"ok": False, "error": "telegram_send_failed"})
    db.execute(
        "INSERT INTO confirms (id, player_id, chat_id, message_id, status, created) VALUES (?,?,?,?,?,?)",
        (req_id, pid, chat_id, msg.message_id, "pending", int(time.time())),
    )
    db.commit()
    return web.json_response(
        {"ok": True, "required": True, "id": req_id, "timeout": CONFIRM_TIMEOUT}
    )


async def api_confirm_status(req: web.Request):
    """GET /confirm/status?id=... -> {"ok":true,"status":"pending|approved|denied|expired"}"""
    if not authorized(req):
        return web.json_response({"ok": False}, status=403)
    req_id = req.query.get("id", "")
    row = db.execute(
        "SELECT status, created, chat_id, message_id FROM confirms WHERE id=?", (req_id,)
    ).fetchone()
    if not row:
        return web.json_response({"ok": True, "status": "expired"})
    st, created, chat_id, message_id = row
    if st == "pending" and time.time() - created > CONFIRM_TIMEOUT:
        st = "expired"
        db.execute("UPDATE confirms SET status='expired' WHERE id=?", (req_id,))
        db.commit()
        try:
            await bot.edit_message_text(
                "⌛ Время вышло. Игрок кикнут с сервера.", chat_id=chat_id, message_id=message_id
            )
        except Exception:
            pass
    return web.json_response({"ok": True, "status": st})


async def main():
    await bot.set_my_commands(
        [
            BotCommand(command="status", description="Мои аккаунты"),
            BotCommand(command="unlink", description="Отвязать аккаунты"),
            BotCommand(command="help", description="Как привязать"),
        ]
    )
    app = web.Application()
    app.add_routes(
        [
            web.post("/tg/link", api_tg_link),
            web.post("/confirm/request", api_confirm_request),
            web.get("/confirm/status", api_confirm_status),
        ]
    )
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, HOST, PORT).start()
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
